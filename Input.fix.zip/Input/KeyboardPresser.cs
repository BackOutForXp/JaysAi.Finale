﻿using System.Runtime.InteropServices;
using System.Windows.Input;

namespace JaysAi.Finale.Input
{
    public static class KeyboardPresser
    {
        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo);

        private const int KEYEVENTF_KEYUP = 0x0002;

        public static void HoldKey(Key key)
        {
            keybd_event((byte)KeyInterop.VirtualKeyFromKey(key), 0, 0, 0);
        }

        public static void ReleaseKey(Key key)
        {
            keybd_event((byte)KeyInterop.VirtualKeyFromKey(key), 0, KEYEVENTF_KEYUP, 0);
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ To finalize this module:
// - [ ] Add GUI checkbox: "Enable Movement Assist"
// - [ ] Hook checkbox to MovementAssist.Toggle()
// - [ ] Extend to use controller movement (GPC or ViGEm) if controller is active
// - [ ] May add jump detection / hop assist / duck spam logic in future phase
// - [ ] Tier-lock to Elite or Owner via FeatureManager.CanUseMovementAssist()
// ===================================================================
