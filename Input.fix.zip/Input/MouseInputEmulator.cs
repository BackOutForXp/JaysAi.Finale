﻿using System;
using System.Runtime.InteropServices;
using System.Numerics;

namespace JaysAi.Finale.Input
{
    public static class MouseInputEmulator
    {
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out System.Drawing.Point lpPoint);

        public static Vector2 GetCursorPosition()
        {
            GetCursorPos(out var point);
            return new Vector2(point.X, point.Y);
        }

        public static void MoveCursorTo(Vector2 position)
        {
            SetCursorPos((int)position.X, (int)position.Y);
        }

        public static void MoveSmoothlyTo(Vector2 target, float smoothing = 0.2f)
        {
            var current = GetCursorPosition();
            var smoothed = Vector2.Lerp(current, target, 1f - smoothing);
            MoveCursorTo(smoothed);
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Moves cursor toward smoothed enemy position
// ✅ Used by AimAssist with legit-style mouse movement
// ✅ Uses SetCursorPos (Win32 API)
// - [ ] Add delta-mode for stealth overlays
// - [ ] Hook into Titan/Titan Two macros via GPC later
// ===================================================================
