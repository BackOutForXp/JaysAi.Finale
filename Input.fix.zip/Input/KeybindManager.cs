﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace JaysAi.Finale.Input
{
    public class KeybindManager
    {
        private readonly Dictionary<string, Key> _keybinds = new();

        public event EventHandler<string>? OnKeyPressed;

        public void RegisterKeybind(string actionName, Key key)
        {
            _keybinds[actionName] = key;
        }

        public void UnregisterKeybind(string actionName)
        {
            if (_keybinds.ContainsKey(actionName))
                _keybinds.Remove(actionName);
        }

        public bool IsKeyPressed(string actionName)
        {
            if (!_keybinds.TryGetValue(actionName, out var key))
                return false;

            return Keyboard.IsKeyDown(key);
        }

        // Call this periodically (e.g., from a DispatcherTimer) to detect presses
        public void CheckKeys()
        {
            foreach (var kvp in _keybinds)
            {
                if (Keyboard.IsKeyDown(kvp.Value))
                {
                    OnKeyPressed?.Invoke(this, kvp.Key);
                }
            }
        }
    }
}
