﻿using System;
using System.Runtime.InteropServices;
using System.Numerics;

namespace JaysAi.Finale.Input
{
    public static class MouseEmulator
    {
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, UIntPtr dwExtraInfo);

        private const uint MOUSEEVENTF_MOVE = 0x0001;

        public static void MoveTo(Vector2 position)
        {
            SetCursorPos((int)position.X, (int)position.Y);
        }

        public static void MoveSmooth(Vector2 current, Vector2 target, float speed)
        {
            Vector2 delta = (target - current) / speed;

            int newX = (int)(current.X + delta.X);
            int newY = (int)(current.Y + delta.Y);

            SetCursorPos(newX, newY);
        }

        public static void Click()
        {
            const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
            const uint MOUSEEVENTF_LEFTUP = 0x0004;

            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Moves mouse toward smooth target location
// ✅ Supports legit-style movement or snap (rage tier)
// ✅ Future support for GPC input or controller spoofing
// - [ ] Add adjustable movement step-size based on tier
// - [ ] Add right-click only trigger toggle
// - [ ] Cronus/Titan script generator mode (Owner tier)
// ===================================================================
