﻿using System.Runtime.InteropServices;

namespace JaysAi.Finale.Input
{
    public static class MouseButtonHelper
    {
        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        private const int VK_LBUTTON = 0x01;
        private const int VK_RBUTTON = 0x02;

        public static bool IsLeftButtonPressed()
        {
            return (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        }

        public static bool IsRightButtonPressed()
        {
            return (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Checks LMB / RMB state in real-time
// ✅ Lightweight + safe for async update loop
// ✅ Used for toggle / hold logic in AimAssist and Recoil
// - [ ] Expand to middle click, side buttons (VK_XBUTTON1/XBUTTON2)
// - [ ] Add support for custom keybind configs from GUI
// ===================================================================
