﻿using System;
using System.Windows.Input;
using System.Windows.Threading;

namespace JaysAi.Finale.Input
{
    public static class InputLogger
    {
        private static DispatcherTimer? _timer;

        private static int _lastX, _lastY;

        public static void Start()
        {
            _lastX = System.Windows.Forms.Cursor.Position.X;
            _lastY = System.Windows.Forms.Cursor.Position.Y;

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(50)
            };
            _timer.Tick += LogInput;
            _timer.Start();
        }

        private static void LogInput(object? sender, EventArgs e)
        {
            var currentX = System.Windows.Forms.Cursor.Position.X;
            var currentY = System.Windows.Forms.Cursor.Position.Y;

            var deltaX = currentX - _lastX;
            var deltaY = currentY - _lastY;

            if (deltaX != 0 || deltaY != 0)
            {
                Console.WriteLine($"[InputLogger] Mouse ΔX:{deltaX} ΔY:{deltaY}");
            }

            if (Keyboard.IsKeyDown(Key.LeftShift))
            {
                Console.WriteLine("[InputLogger] Key Pressed: LeftShift");
            }

            // Update last
            _lastX = currentX;
            _lastY = currentY;
        }

        public static void Stop()
        {
            _timer?.Stop();
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ To finalize this module:
// - [x] Call InputLogger.Start() on App startup (after license check)
// - [ ] Replace with controller input via SharpDX/XInput later
// - [ ] Integrate with AimAssist to analyze correction vs movement
// - [ ] Optional: Log keystrokes for behavior tracking AI
// ===================================================================
