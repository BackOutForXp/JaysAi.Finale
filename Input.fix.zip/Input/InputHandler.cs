﻿using System;
using System.Runtime.InteropServices;

namespace JaysAi.Finale.Input
{
    public static class InputHandler
    {
        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

        private const uint MOUSEEVENTF_MOVE = 0x0001;
        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const uint MOUSEEVENTF_LEFTUP = 0x0004;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const uint MOUSEEVENTF_RIGHTUP = 0x0010;

        public static void MoveMouse(int dx, int dy)
        {
            mouse_event(MOUSEEVENTF_MOVE, (uint)dx, (uint)dy, 0, UIntPtr.Zero);
        }

        public static void LeftClick()
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
        }

        public static void RightClick()
        {
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, UIntPtr.Zero);
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, UIntPtr.Zero);
        }

        public static void FirePulse()
        {
            LeftClick(); // Future: Add burst control based on recoil pattern
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Handles mouse click + movement injection
// ✅ Used by AimAssist, AntiRecoil, and future controller logic
// ✅ Modular: supports real hardware later (Cronus, Titan, GPC)
// - [ ] Add controller emulation (ViGEm / Interception)
// - [ ] Map virtual joystick to AimAssist target vector
// ===================================================================
