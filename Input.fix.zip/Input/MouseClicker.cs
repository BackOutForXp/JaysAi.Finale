﻿using System;
using System.Runtime.InteropServices;

namespace JaysAi.Finale.Input
{
    public static class MouseClicker
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, UIntPtr dwExtraInfo);

        private const uint MOUSEEVENTF_LEFTDOWN = 0x02;
        private const uint MOUSEEVENTF_LEFTUP = 0x04;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const uint MOUSEEVENTF_RIGHTUP = 0x10;

        public static void LeftClick()
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
        }

        public static void RightDown()
        {
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, UIntPtr.Zero);
        }

        public static void RightUp()
        {
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, UIntPtr.Zero);
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Used by: TriggerBot.cs, AdsAssist.cs
// - [x] Supports: LeftClick(), RightDown(), RightUp()
// - [ ] Future: Add support for controller emulation (SendInput or ViGEm)
// - [ ] Consider adding MiddleClick, Scroll emulation, or drag macros
// ===================================================================
