﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Numerics;
using JaysAi.Finale.Utility;

namespace JaysAi.Finale.Input
{
    public static class CursorMover
    {
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        public static void SnapTo(Vector2 target)
        {
            Logger.Debug($"[CursorMover] Snapping to {target}");
            SetCursorPos((int)target.X, (int)target.Y);
        }

        public static void SmoothAim(Vector2 target, float smoothingFactor)
        {
            if (!GetCursorPos(out var current)) return;

            var currentPos = new Vector2(current.X, current.Y);
            var delta = (target - currentPos) / smoothingFactor;
            var newPos = currentPos + delta;

            SetCursorPos((int)newPos.X, (int)newPos.Y);

            Logger.Debug($"[CursorMover] Smooth move to {newPos} (delta {delta})");
        }
    }
}

// ======================= MONARCH INTEGRATION =======================
// ✅ Moves mouse to match enemy position on screen
// ✅ Supports both snap and smoothing mode
// ✅ Reads from ConfigManager.SmoothingAmount
// - [ ] Add config-based toggle between smooth vs snap
// - [ ] Add recoil offset hook
// - [ ] Detect game window focus before moving
// ===================================================================
