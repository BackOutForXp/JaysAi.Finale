﻿// MonarchMode.Input.InputEmulator.cs
using System;
using System.Runtime.InteropServices;
using System.Numerics;

namespace JaysAi.Finale.Input
{
    public static class InputEmulator
    {
        public enum InputMode
        {
            Mouse,
            VirtualStick
        }

        public static InputMode Mode { get; set; } = InputMode.Mouse;

        public static void ApplyAimAdjustment(Vector2 aimDelta)
        {
            switch (Mode)
            {
                case InputMode.Mouse:
                    MoveMouseRelative((int)aimDelta.X, (int)aimDelta.Y);
                    break;

                case InputMode.VirtualStick:
                    EmulateStick(aimDelta);
                    break;
            }
        }

        private static void MoveMouseRelative(int dx, int dy)
        {
            INPUT[] inputs = new INPUT[]
            {
                new INPUT
                {
                    type = 0, // INPUT_MOUSE
                    U = new InputUnion
                    {
                        mi = new MOUSEINPUT
                        {
                            dx = dx,
                            dy = dy,
                            dwFlags = MOUSEEVENTF_MOVE
                        }
                    }
                }
            };

            SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        }

        private static void EmulateStick(Vector2 delta)
        {
            // Placeholder for Cronus Zen, Titan Two, or ViGEm injection
            Console.WriteLine($"[InputEmulator] Stick nudge: {delta}");
        }

        #region WinAPI Mouse Interop

        private const int INPUT_MOUSE = 0;
        private const uint MOUSEEVENTF_MOVE = 0x0001;

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public int type;
            public InputUnion U;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        #endregion
    }
}

// TODO ✅ Add mouse aim nudge via SendInput
// TODO ✅ Stub stick aiming logic for Cronus Zen
// TODO ☐ Add input smoothing and curves
// TODO ☐ Allow config override of input mode
// TODO ☐ Hook into ViGEm or third-party virtual pad library
